# bridge init
