from pathlib import Path
import json, time

LOG_DIR = Path("/srv/cockswain-core/logs")
LOG_DIR.mkdir(parents=True, exist_ok=True)
LOG_FILE = LOG_DIR / "hybrid_engine_meta.log"

class MetaLog:
    @staticmethod
    def record(tag: str, obj: dict):
        obj = {"tag": tag, "ts": time.time(), **obj}
        with LOG_FILE.open("a", encoding="utf-8") as f:
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")
