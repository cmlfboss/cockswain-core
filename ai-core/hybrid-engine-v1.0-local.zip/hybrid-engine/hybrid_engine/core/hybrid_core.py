import asyncio, json, time
from pathlib import Path
from .ssl_context_builder import load_ssl_config, build_ssl_context, secure_connection
from .arbiter_gateway import create_decision, verify_proof
from .meta import MetaLog

CFG = {
    "ssl_config_path": str(Path(__file__).resolve().parents[1] / "config" / "ssl.json"),
    "app_config_path": str(Path(__file__).resolve().parents[1] / "config" / "app.json"),
}

async def run_task(payload):
    decision = create_decision("execute", payload, author="hybrid_core")
    assert verify_proof(decision), "Proof verification failed"
    MetaLog.record("task_start", {"decision_id": decision["decision_id"], "payload": payload})
    await asyncio.sleep(0.2)
    MetaLog.record("task_end", {"decision_id": decision["decision_id"], "result": "ok"})
    return {"ok": True, "decision_id": decision["decision_id"]}

async def main():
    ssl_cfg = load_ssl_config(CFG["ssl_config_path"])
    build_ssl_context(ssl_cfg.get("cert_file",""), ssl_cfg.get("key_file",""),
                      ssl_cfg.get("check_hostname", False), ssl_cfg.get("verify_mode","CERT_NONE"))
    results = []
    for i in range(3):
        results.append(await run_task({"job": i, "ts": time.time()}))
    Path(Path(__file__).resolve().parent / "startup.ok").write_text(json.dumps(results, ensure_ascii=False), encoding="utf-8")

if __name__ == "__main__":
    asyncio.run(main())
